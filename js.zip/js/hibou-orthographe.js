/* Maître Hibou V25.7.53 — Orthographe / dictée modulaire en JSON
   Bandeau compact tablette + exercices fondés sur le guide ministériel CE1,
   adaptés à l'entraînement CE2. Contenu séparé dans data/orthographe_dictee.json.
*/
(function(){
  'use strict';
  if(window.__hibouOrthographeV25730) return;
  window.__hibouOrthographeV25730 = true;

  var DATA_URL = 'data/orthographe_dictee.json?v=25730';
  var CACHE_KEY = 'hibou_orthographe_dictee_json_v25730';
  var state = { data:null, activity:null, questions:[], index:0, score:0, total:0, answers:[], segmentIndex:0, item:null, attempts:0, firstCorrect:false };

  function $(id){ return document.getElementById(id); }
  function popupInner(){ return $('frenchPopupInnerV2348'); }
  function clean(v){ return String(v == null ? '' : v).replace(/\s+/g,' ').trim(); }
  function esc(v){ return String(v == null ? '' : v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
  function norm(v){ return clean(v).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[’']/g,' ').replace(/[^a-z0-9]+/g,' ').trim(); }
  function shuffle(a){ var out=(a||[]).slice(); for(var i=out.length-1;i>0;i--){ var j=Math.floor(Math.random()*(i+1)); var t=out[i]; out[i]=out[j]; out[j]=t; } return out; }
  function setInner(html){ var el=popupInner(); if(el) el.innerHTML=html; var ov=$('frenchTrainingOverlayV2348'); if(ov) ov.classList.remove('ortho-menu-compact','ortho-qcm-compact','ortho-segment-compact'); }

  function activityLabel(type){
    return type==='mot_correct'?'Choisis le mot bien écrit':
      type==='erreur'?'Corrige l’erreur':
      type==='dictee_segmentee'?'Dictée segmentée':'Orthographe';
  }

  function setOrthoTopbar(activity, showReturn){
    var chip=document.querySelector('#frenchTrainingOverlayV2348 .fr-v2348-chip');
    if(!chip) return;
    chip.classList.add('ortho-v25730-topbar-chip');
    var label=activity ? activityLabel(activity) : '';
    chip.innerHTML='<span class="ortho-v25730-topbar-title">📖 Français <b>—</b> 🔤 Orthographe'+(label?' <b>—</b> '+esc(label):'')+'</span>'+
      (showReturn?'<button type="button" class="ortho-v25730-topbar-return" onclick="'+(showReturn==='menu'?'renderFrenchDomainMenuV25720()':'openHibouOrthographeV25730()')+'">'+(showReturn==='menu'?'← Retour au menu Français':'← Retour Orthographe')+'</button>':'');
  }

  function resetFrenchTopbar(){
    var chip=document.querySelector('#frenchTrainingOverlayV2348 .fr-v2348-chip');
    if(!chip) return;
    chip.classList.remove('ortho-v25730-topbar-chip');
    chip.textContent='📖 Français';
  }

  function header(title, subtitle, note){
    return '<div class="fr-v2348-header"><div class="fr-v2348-owl">🦉</div><div class="fr-v2348-title"><h2>'+esc(title||'🔤 Orthographe')+'</h2><p>'+esc(subtitle||'Choisis un entraînement.')+'</p>'+(note===null?'':'<div class="fr-v23411-grammar-note">'+esc(note||'Les exercices sont chargés depuis un fichier JSON externe.')+'</div>')+'</div></div>';
  }

  function injectStyle(){
    if($('hibouOrthographeV25730Style')) return;
    var css = ''+
    '.ortho-v25730-menu{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-top:12px}'+
    '.ortho-v25730-card{border:2px solid #bbf7d0;background:linear-gradient(135deg,#f0fdf4,#fff);border-radius:22px;padding:18px 14px;text-align:center;font-family:inherit;font-weight:900;color:#14532d;cursor:pointer;box-shadow:0 8px 24px rgba(22,163,74,.12)}'+
    '.ortho-v25730-card:hover{transform:translateY(-1px);box-shadow:0 12px 28px rgba(22,163,74,.16)}'+
    '.ortho-v25730-icon{font-size:42px;margin-bottom:8px}.ortho-v25730-title{font-size:20px;color:#0f5132}.ortho-v25730-desc{font-size:13px;color:#287047;margin-top:5px;line-height:1.25}'+
    '.ortho-v25730-box{background:#fff;border:2px solid #d9f99d;border-radius:18px;padding:16px;margin-top:8px}'+
    '.ortho-v25730-question{background:#f7fee7;border:2px solid #bef264;border-radius:16px;padding:14px;font-size:20px;font-weight:1000;color:#1f3d0c;margin:8px 0;line-height:1.3}'+
    '.ortho-v25730-mot-visual{display:flex;justify-content:center;align-items:center;margin:12px 0}.ortho-v25730-mot-visual img{display:block;width:min(200px,48vw);height:min(200px,48vw);object-fit:contain;border-radius:14px}'+
    '.ortho-v25730-box:has(.ortho-v25730-mot-visual) .ortho-v25730-options{display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}@media(max-width:560px){.ortho-v25730-box:has(.ortho-v25730-mot-visual) .ortho-v25730-options{grid-template-columns:1fr}}'+
    '.ortho-v25730-options{display:flex;flex-direction:column;gap:9px;margin-top:10px}.ortho-v25730-option{border:2px solid #e5e7eb;background:#fff;border-radius:14px;padding:12px 14px;text-align:left;font-size:17px;font-weight:900;color:#172554;font-family:inherit;cursor:pointer}'+
    '.ortho-v25730-option.correct{background:#dcfce7!important;border-color:#22c55e!important;color:#14532d!important}.ortho-v25730-option.wrong{background:#fee2e2!important;border-color:#ef4444!important;color:#7f1d1d!important}'+
    '.ortho-v25730-feedback{margin-top:12px;border-radius:14px;padding:12px;font-weight:900;text-align:center}.ortho-v25730-feedback.ok{background:#dcfce7;color:#14532d;border:2px solid #86efac}.ortho-v25730-feedback.warn{background:#fff7ed;color:#7c2d12;border:2px solid #fdba74}'+
    '.ortho-v25730-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px}.ortho-v25730-btn{border:0;border-radius:14px;background:#16a34a;color:#fff;padding:11px 14px;font-weight:1000;font-family:inherit;cursor:pointer}.ortho-v25730-btn.secondary{background:#fff;color:#166534;border:2px solid #bbf7d0}'+
    '.ortho-v25730-input{width:100%;border:3px solid #bbf7d0;border-radius:16px;padding:13px 14px;font-size:20px;font-weight:900;color:#172554;outline:none}.ortho-v25730-input:focus{box-shadow:0 0 0 4px rgba(34,197,94,.16)}'+
    '.ortho-v25730-model{font-size:15px;color:#64748b;font-weight:850;margin:8px 0}.ortho-v25730-progress{font-size:15px;font-weight:900;color:#166534;margin-bottom:8px}'+
    '#frenchTrainingOverlayV2348 .fr-v2348-chip.ortho-v25730-topbar-chip{flex:1;max-width:none;background:transparent!important;box-shadow:none!important;border:0!important;padding:0!important;display:flex;align-items:center;justify-content:space-between;gap:14px;color:#fff!important;font-weight:1000}'+
    '.ortho-v25730-topbar-title{font-size:17px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ortho-v25730-topbar-title b{opacity:.78;margin:0 4px}.ortho-v25730-topbar-return{border:2px solid rgba(255,255,255,.8);background:rgba(255,255,255,.18);color:#fff;border-radius:999px;padding:7px 12px;font:inherit;font-size:14px;font-weight:1000;cursor:pointer;white-space:nowrap}.ortho-v25730-topbar-return:hover{background:rgba(255,255,255,.28)}'+
    '@media(max-width:820px){.ortho-v25730-topbar-title{font-size:15px}.ortho-v25730-topbar-return{font-size:12px;padding:6px 9px}.ortho-v25730-menu{grid-template-columns:1fr}.ortho-v25730-card{padding:14px}.ortho-v25730-icon{font-size:34px}.ortho-v25730-box{padding:12px;margin-top:6px}.ortho-v25730-question{font-size:18px;margin:7px 0}.ortho-v25730-option{font-size:16px}}';
    css += '.ortho-v25730-menu{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;align-items:start;margin:14px 0 0}'+
    '.ortho-v25730-card{display:block;width:100%;padding:0!important;overflow:hidden;line-height:0;background:#fff!important;border-radius:24px;box-shadow:none;transition:box-shadow .18s,transform .18s}'+
    '.ortho-v25730-card-mot{border:3px solid #c4b5fd!important;background:#f3edff!important}'+
    '.ortho-v25730-card-erreur{border:3px solid #93c5fd!important;background:#e8f3ff!important}'+
    '.ortho-v25730-card-dictee{border:3px solid #86efac!important;background:#e9f9ee!important}'+
    '.ortho-v25730-card img{display:block;width:100%;height:auto;aspect-ratio:2/1;object-fit:contain}'+
    '.ortho-v25730-card:hover{transform:translateY(-2px);box-shadow:0 8px 16px rgba(25,50,80,.12)}'+
    '.ortho-v25730-card:focus-visible{outline:4px solid #2563eb;outline-offset:3px}'+
    '@media(max-width:700px){.ortho-v25730-menu{grid-template-columns:1fr;gap:12px}.ortho-v25730-card{border-radius:18px}}';
    css += '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-topbar{min-height:50px;padding:6px 12px}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-close{width:40px;height:40px;font-size:27px}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact #frenchPopupInnerV2348{display:block;overflow-y:auto!important;overflow-x:hidden!important;overscroll-behavior:contain;touch-action:pan-y;scrollbar-width:auto}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-menu-head{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;padding:12px 18px 8px}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-menu-heading{display:flex;gap:10px;align-items:center;min-width:0}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-menu-heading h2{font-size:clamp(23px,2.5vw,32px);line-height:1.2;margin:0;color:#2d2b55}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-menu-heading .ortho-owl{font-size:27px}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-menu-head .fr-v2348-back{margin:0;white-space:normal}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-content{display:block;overflow:visible!important;min-height:0;padding:4px 16px 18px}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-panel{display:block;overflow:visible!important;min-height:0;padding:10px 12px 16px}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-menu{margin:0;gap:14px}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-card img{height:auto;aspect-ratio:2/1;object-fit:contain}'+
    '@media(max-width:700px){#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-menu-head{padding:10px 12px 8px}#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-content{padding:4px 10px 14px}}';
    // NAV-02 : mise en page compacte du QCM et défilement unique dans la fenêtre.
    css += '#frenchTrainingOverlayV2348.ortho-qcm-compact .fr-v2348-topbar{min-height:50px;padding:6px 12px}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .fr-v2348-close{width:40px;height:40px;font-size:27px}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact #frenchPopupInnerV2348{flex:1 1 auto;min-height:0;display:block;overflow-y:auto!important;overflow-x:hidden!important;overscroll-behavior:contain;touch-action:pan-y;scrollbar-width:auto}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .fr-v2348-content{display:block;overflow:visible!important;min-height:0;padding:8px 12px 14px}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .fr-v2348-panel{display:block;overflow:visible!important;min-height:0;padding:10px 12px 14px}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-v25730-box{padding:12px;margin:0}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-v25730-question{padding:10px 14px;margin:6px 0 12px}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-qcm-body.has-image{display:grid;grid-template-columns:minmax(150px,230px) minmax(0,1fr);gap:18px;align-items:center}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-v25730-mot-visual{margin:0;min-width:0}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-v25730-mot-visual img{width:100%;max-width:220px;height:auto;aspect-ratio:1;object-fit:contain;border-radius:12px}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-v25730-options{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:0}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-qcm-body.has-image .ortho-v25730-options{grid-template-columns:minmax(0,1fr)!important}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-v25730-option{min-height:54px;padding:11px 14px;line-height:1.25}'+
    '@media(max-width:650px){#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-qcm-body.has-image{grid-template-columns:1fr;gap:12px}#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-v25730-mot-visual img{max-width:160px}#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-v25730-options{grid-template-columns:1fr!important}#frenchTrainingOverlayV2348.ortho-qcm-compact .fr-v2348-content{padding:6px}}';
    css += '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-dictee-model{background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;padding:10px 12px;margin:8px 0;color:#1e3a8a}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-dictee-model p{margin:0 0 8px;line-height:1.35}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-dictee-model .ortho-v25730-question{margin:0 0 8px;padding:8px 10px}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-dictee-compose{display:grid;grid-template-columns:minmax(0,210px) minmax(0,1fr);gap:16px;align-items:center}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-dictee-compose:not(.has-image){display:block}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-dictee-compose img{width:100%;max-width:200px;height:auto;aspect-ratio:1;object-fit:contain}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-dictee-write[hidden]{display:none!important}'+
    '#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-dictee-model[hidden]{display:none!important}'+
    '@media(max-width:650px){#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-dictee-compose.has-image{grid-template-columns:1fr}#frenchTrainingOverlayV2348.ortho-qcm-compact .ortho-dictee-compose img{max-width:135px;display:block;margin:auto}}';
    // NAV-02 : menu Orthographe resserré, sans recadrage des 3 illustrations.
    css += '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-popup{height:min(96dvh,1000px);max-height:96dvh}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-topbar{min-height:48px!important;padding:4px 10px!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-close{width:36px;height:36px;font-size:25px}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact #frenchPopupInnerV2348{flex:1 1 auto;min-height:0;overflow-y:scroll!important;overflow-x:hidden!important;scrollbar-width:thin;-webkit-overflow-scrolling:touch;touch-action:pan-y}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-menu-head{padding:7px 12px 5px!important;gap:8px!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-menu-heading{gap:7px!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-menu-heading h2{font-size:clamp(22px,2.2vw,29px)!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-menu-heading .ortho-owl{font-size:24px!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-menu-head .fr-v2348-back{padding:7px 12px!important;font-size:14px!important;min-height:36px!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-content{padding:0 8px 8px!important;margin:0!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-panel{padding:6px!important;margin:0!important;border-radius:16px!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-menu{gap:8px!important;margin:0!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-card{border-width:2px!important;border-radius:16px!important;line-height:0!important;padding:0!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-card img{display:block;width:100%;height:auto!important;aspect-ratio:2/1;object-fit:contain!important}'+
    '@media(max-width:700px){#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-menu-head{padding:7px 8px 5px!important}#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-menu{grid-template-columns:1fr!important;gap:8px!important}}';
    // Menu Orthographe : titre et retour dans le bandeau ; cartes sans en-tête redondant.
    css += '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-topbar{min-height:48px!important;padding:4px 12px!important;gap:10px!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-chip.ortho-v25730-topbar-chip{display:flex!important;flex:1 1 auto!important;min-width:0;max-width:none!important;justify-content:space-between!important;gap:12px!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-topbar-title{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-topbar-return{flex:0 0 auto;min-height:36px;white-space:nowrap}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-content{padding:6px 8px 8px!important;margin:0!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-panel{padding:6px!important}'+
    '@media(max-width:580px){#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-topbar-title{font-size:13px}#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-topbar-return{font-size:11px;padding:6px 8px}}';
    // Alignement du catalogue Orthographe sur le catalogue Vocabulaire :
    // hauteur dictée par la vraie image 2:1, pas par les hauteurs minimales globales des boutons.
    css += '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-menu{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px!important;align-items:start!important;align-content:start!important;margin:0!important;padding:0!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-card{display:block!important;box-sizing:border-box!important;width:100%!important;height:auto!important;min-height:0!important;max-height:none!important;aspect-ratio:auto!important;padding:4px!important;margin:0!important;line-height:0!important;border-width:2px!important;border-radius:20px!important;overflow:hidden!important;align-self:start!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-card img{display:block!important;width:100%!important;height:auto!important;max-height:none!important;min-height:0!important;aspect-ratio:2/1!important;object-fit:contain!important;margin:0!important;padding:0!important;border-radius:15px!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-content{padding:8px 12px 12px!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-panel{padding:0!important;margin:0!important;border:0!important;box-shadow:none!important;background:transparent!important}'+
    '@media(max-width:700px){#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-menu{grid-template-columns:1fr!important;gap:10px!important}#frenchTrainingOverlayV2348.ortho-menu-compact .fr-v2348-content{padding:6px 8px 10px!important}}';
    // Les JPG de menu incluent eux-memes des bandes blanches verticales.
    // On resserre UNIQUEMENT le cadre, en gardant la largeur et l'echelle du visuel.
    // Le cadrage couvre les bandes blanches, sans couper les contenus illustrés.
    css += '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-menu{row-gap:8px!important;column-gap:10px!important;align-content:start!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-card{position:relative!important;aspect-ratio:2.50/1!important;height:auto!important;min-height:0!important;max-height:none!important;padding:0!important;margin:0!important;overflow:hidden!important;align-self:start!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-card img{position:absolute!important;inset:0!important;display:block!important;width:100%!important;height:100%!important;min-height:0!important;max-height:none!important;aspect-ratio:auto!important;object-fit:cover!important;object-position:center center!important;margin:0!important;padding:0!important;border-radius:0!important}'+
    '#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-card-dictee{aspect-ratio:2.10/1!important}'+
    '@media(max-width:700px){#frenchTrainingOverlayV2348.ortho-menu-compact .ortho-v25730-menu{row-gap:8px!important;column-gap:8px!important}}';
    var style=document.createElement('style'); style.id='hibouOrthographeV25730Style'; style.textContent=css; document.head.appendChild(style);
  }

  function loadData(force){
    if(state.data && !force) return Promise.resolve(state.data);
    if(!force){ try{ var cached=JSON.parse(localStorage.getItem(CACHE_KEY)||'null'); if(cached && cached.exercices){ state.data=cached; return Promise.resolve(cached); } }catch(e){} }
    return fetch(DATA_URL,{cache:'no-store'}).then(function(r){ if(!r.ok) throw new Error('json '+r.status); return r.json(); }).then(function(data){ state.data=data||{exercices:[]}; try{ localStorage.setItem(CACHE_KEY,JSON.stringify(state.data)); }catch(e){} return state.data; }).catch(function(err){ console.warn('Orthographe JSON indisponible',err); return {exercices:[]}; });
  }

  function activeItems(type){
    var data=state.data||{exercices:[]};
    return (data.exercices||[]).filter(function(x){ return String(x.actif||'oui').toLowerCase()!=='non' && (!type || x.type===type); });
  }

  function patchDomainMenu(){
    var card=document.querySelector('#frenchTrainingOverlayV2348 .fr-v25720-domain-card.ortho');
    if(!card || card.__hibouOrthoPatched25730) return;
    card.__hibouOrthoPatched25730=true; card.disabled=false; card.removeAttribute('disabled'); card.removeAttribute('aria-disabled'); card.classList.remove('is-disabled');
    var soon=card.querySelector('.fr-v25720-domain-soon'); if(soon){ soon.className='fr-v25720-domain-arrow'; soon.textContent='›'; }
    card.onclick=function(ev){ ev.preventDefault(); window.openHibouOrthographeV25730(); };
  }

  function installMenuPatch(){
    function wrap(name){
      var fn=window[name]; if(typeof fn!=='function' || fn.__hibouOrthoWrapped25730) return;
      var wrapped=function(){ var r=fn.apply(this,arguments); setTimeout(patchDomainMenu,0); setTimeout(patchDomainMenu,80); return r; };
      wrapped.__hibouOrthoWrapped25730=true; window[name]=wrapped;
    }
    wrap('renderFrenchDomainMenuV25720');
    var frenchMenu=window.renderFrenchDomainMenuV25720;
    if(typeof frenchMenu==='function' && !frenchMenu.__orthoTopbarReset25730){
      var resetWrapped=function(){ resetFrenchTopbar(); return frenchMenu.apply(this,arguments); };
      resetWrapped.__hibouOrthoWrapped25730=true; resetWrapped.__orthoTopbarReset25730=true; window.renderFrenchDomainMenuV25720=resetWrapped;
    }
    wrap('openFrenchTrainingPopupV2348'); setTimeout(patchDomainMenu,0); setTimeout(patchDomainMenu,300);
  }

  function showLoading(){
    setOrthoTopbar('',false);
    setInner(header('🔤 Orthographe','Chargement des exercices.','Les exercices sont dans data/orthographe_dictee.json.')+'<div class="fr-v2348-content"><section class="fr-v2348-panel"><div class="fr-v2348-feedback" style="padding:22px">🦉 Chargement rapide des exercices...</div></section></div>');
  }

  function renderMenu(){
    setOrthoTopbar('','menu');
    setInner(''+
      '<div class="fr-v2348-content"><section class="fr-v2348-panel">'+
      '<div class="ortho-v25730-menu">'+
      '<button class="ortho-v25730-card ortho-v25730-card-mot" type="button" aria-label="Choisis le mot bien écrit" onclick="startHibouOrthographeV25730(\'mot_correct\')"><img src="images/orthographe-choisis-mot.jpg" alt="Choisis le mot bien écrit — observer, comparer et mémoriser l’orthographe des mots" loading="eager"></button>'+
      '<button class="ortho-v25730-card ortho-v25730-card-erreur" type="button" aria-label="Corrige l’erreur" onclick="startHibouOrthographeV25730(\'erreur\')"><img src="images/orthographe-corrige-erreur.jpg" alt="Corrige l’erreur — identifier la difficulté et choisir une correction raisonnée" loading="eager"></button>'+
      '<button class="ortho-v25730-card ortho-v25730-card-dictee" type="button" aria-label="Dictée segmentée" onclick="startHibouOrthographeV25730(\'dictee_segmentee\')"><img src="images/orthographe-dictee-segmentee.jpg" alt="Dictée segmentée — écrire par groupes de sens et vérifier chaque segment" loading="eager"></button>'+
      '</div></section></div>');
    var ov=$('frenchTrainingOverlayV2348'); if(ov) ov.classList.add('ortho-menu-compact');
  }

  window.openHibouOrthographeV25730=function(){ injectStyle(); showLoading(); loadData(false).then(renderMenu); };

  window.startHibouOrthographeV25730=function(type){
    loadData(false).then(function(){
      if(type==='dictee_segmentee') return startSegmented();
      var items=shuffle(activeItems(type)).slice(0,10);
      state.activity=type; state.questions=items; state.index=0; state.score=0; state.total=items.length; state.answers=[]; state.attempts=0;
      if(!items.length) return renderNoData(type); renderQcm();
    });
  };

  function renderNoData(type){
    setOrthoTopbar(type,true);
    setInner('<div class="fr-v2348-content"><section class="fr-v2348-panel"><div class="ortho-v25730-feedback warn">Aucun exercice disponible pour : '+esc(activityLabel(type))+'</div><div class="ortho-v25730-actions"><button class="ortho-v25730-btn secondary" onclick="openHibouOrthographeV25730()">← Retour Orthographe</button></div></section></div>'); var overlay=$('frenchTrainingOverlayV2348'); if(overlay) overlay.classList.add('ortho-qcm-compact');
  }

  function optionsFor(item){
    return shuffle([item.bonne_reponse,item.erreur_1,item.erreur_2,item.erreur_3].filter(function(x){return clean(x);})).map(function(x){return {text:x,ok:norm(x)===norm(item.bonne_reponse)};});
  }

  // NAV-02 : photographies locales individuelles contrôlées (36 mots).
  var MOT_IMAGES_400 = {
    important:'important.jpg', peinture:'peinture.jpg', pharmacie:'pharmacie.jpg', taxi:'taxi.jpg', addition:'addition.jpg',
    malheureux:'malheureux.jpg', kangourou:'kangourou.jpg',
    tambour:'tambour.jpg', poussin:'poussin.jpg', girafe:'girafe.jpg',
    champignon:'champignon.jpg', foret:'foret.jpg', chorale:'chorale.jpg',
    emmener:'emmener.jpg', facteur:'facteur.jpg', femme:'femme.jpg',
    monsieur:'monsieur.jpg', joyeux:'joyeux.jpg', maison:'maison.jpg', marcher:'marcher.jpg', cherchez:'cherchez.jpg', action:'action.jpg', attention:'attention.jpg', bosquet:'bosquet.jpg', chameau:'chameau.jpg', nageoire:'nageoire.jpg', garcon:'garcon.jpg', guirlande:'guirlande.jpg', musicien:'musicien.jpg', symbole:'symbole.jpg', visiteuse:'visiteuse.jpg', ocean:'ocean.jpg', bateau:'bateau.jpg', beaucoup:'beaucoup.jpg', jardinier:'jardinier.jpg', chanteuse:'chanteuse.jpg'
  };
  var CORRIGE_IMAGES = new Set(['tambour','emmener','poussin','peinture','girafe','guirlande','champignon','garcon','maison','chameau','monsieur','jardinier','chanteuse','attention','addition','pharmacie','marcher']);
  var DICTEE_IMAGES = {
    'La maison est près du chemin.':'maison.jpg',
    'Le tambour résonne dans la cour.':'tambour.jpg',
    'Un poussin marche dans le jardin.':'poussin.jpg',
    'Vous cherchez le chemin de la forêt.':'foret.jpg',
    'Le garçon mange un morceau de gâteau.':'garcon.jpg'
  };
  function renderMotImage(item){
    if(state.activity !== 'mot_correct' && state.activity !== 'erreur') return '';
    var word=norm(item.bonne_reponse);
    if(state.activity === 'erreur' && !CORRIGE_IMAGES.has(word)) return '';
    var file = MOT_IMAGES_400[word];
    return file ? '<div class="ortho-v25730-mot-visual"><img src="images/orthographe/'+file+'" alt="Illustration pour aider à reconnaître le mot" width="200" height="200" decoding="async"></div>' : '';
  }
  function orthographeIndice(item){
    var c=clean(item.competence||'').toLowerCase();
    if(c.includes('devant p')||c.includes('devant b')||c.includes('m devant'))return 'Observe la lettre qui suit le son nasal : devant m, b ou p, on emploie souvent m.';
    if(c.includes('accent'))return 'Prononce le mot doucement et regarde les accents possibles.';
    if(c.includes('pluriel')||c.includes('accord'))return 'Cherche le nombre du nom et vérifie les marques d’accord.';
    if(c.includes('lettre muette'))return 'Pense à un mot de la même famille pour retrouver une lettre finale.';
    if(c.includes('son'))return 'Lis chaque proposition lentement et compare les lettres qui écrivent le son.';
    if(state.activity==='erreur')return 'Relis le mot et compare chaque lettre avec ce que tu connais de son orthographe.';
    return 'Relis les propositions et cherche la règle ou la partie du mot que tu connais.';
  }
  window.showHibouOrthoHintV25730=function(){
    var hint=$('orthoHintV25730');if(hint)hint.hidden=false;
  };
  function renderQcm(){
    setOrthoTopbar(state.activity,true);
    var item=state.questions[state.index]; if(!item) return renderResult();
    var html=optionsFor(item).map(function(o){ return '<button type="button" class="ortho-v25730-option" data-ok="'+(o.ok?'1':'0')+'" onclick="answerHibouOrthographeV25730(this)">'+esc(o.text)+'</button>'; }).join('');
    var imageHtml=renderMotImage(item);
    state.attempts=0;
    setInner('<div class="fr-v2348-content"><section class="fr-v2348-panel"><div class="ortho-v25730-box"><div class="ortho-v25730-progress">Question '+(state.index+1)+' / '+state.total+'</div><div class="ortho-v25730-question">'+esc(item.question||item.consigne||'Choisis la bonne réponse.')+'</div><div class="ortho-qcm-body'+(imageHtml?' has-image':'')+'">'+imageHtml+'<div class="ortho-v25730-options">'+html+'</div></div><div class="ortho-v25730-actions"><button class="ortho-v25730-btn" type="button" onclick="showHibouOrthoHintV25730()">💡 Besoin d’un indice ?</button></div><div id="orthoHintV25730" class="ortho-v25730-feedback" hidden>'+esc(orthographeIndice(item))+'</div><div id="orthoFeedbackV25730"></div></div></section></div>');
    var overlay=$('frenchTrainingOverlayV2348'); if(overlay) overlay.classList.add('ortho-qcm-compact');
  }

  window.answerHibouOrthographeV25730=function(btn){
    var item=state.questions[state.index];if(!item||btn.disabled)return;
    var buttons=[].slice.call(document.querySelectorAll('.ortho-v25730-option'));
    var ok=btn.getAttribute('data-ok')==='1';
    state.attempts++;
    var fb=$('orthoFeedbackV25730');
    if(!ok&&state.attempts===1){
      btn.disabled=true;btn.classList.add('wrong');
      window.showHibouOrthoHintV25730();
      if(fb)fb.innerHTML='<div class="ortho-v25730-feedback warn">Ce n’est pas encore juste. Lis l’indice, puis essaie une autre réponse.</div>';
      return;
    }
    buttons.forEach(function(b){b.disabled=true;if(b.getAttribute('data-ok')==='1')b.classList.add('correct');});
    if(!ok)btn.classList.add('wrong');
    if(ok&&state.attempts===1)state.score++;
    state.answers.push({question:item.question,ok:ok,competence:item.competence||'',attempts:state.attempts,withHint:state.attempts>1});
    var next=(state.index+1>=state.total)?'Voir le résultat':'Question suivante';
    if(fb)fb.innerHTML='<div class="ortho-v25730-feedback '+(ok?'ok':'warn')+'">'+(ok?(state.attempts===1?'✅ Bravo !':'✅ Bravo, tu as trouvé après l’indice !'):'💡 Correction : '+esc(item.bonne_reponse||''))+(item.explication?'<br><small>'+esc(item.explication)+'</small>':'')+'</div><div class="ortho-v25730-actions"><button class="ortho-v25730-btn" onclick="nextHibouOrthographeQuestionV25730()">'+next+'</button></div>';
  };
  window.nextHibouOrthographeQuestionV25730=function(){ state.index++; if(state.index>=state.total) renderResult(); else renderQcm(); };

  function startSegmented(){
    var items=shuffle(activeItems('dictee_segmentee'));
    state.activity='dictee_segmentee'; state.item=items[0]||null; state.segmentIndex=0; state.score=0; state.answers=[]; state.attempts=0;
    if(!state.item) return renderNoData('dictee_segmentee');
    state.questions=[state.item.segment_1,state.item.segment_2,state.item.segment_3,state.item.segment_4].filter(function(x){return clean(x);}); state.total=state.questions.length; renderSegment();
  }

  function renderSegment(){
    setOrthoTopbar('dictee_segmentee',true);
    var seg=state.questions[state.segmentIndex]; if(!seg) return renderResult();
    state.attempts=0;
    var file=DICTEE_IMAGES[state.item.question||''];
    var imageHtml=file?'<div class="ortho-v25730-mot-visual"><img src="images/orthographe/'+file+'" alt="Illustration de la phrase" width="200" height="200"></div>':'';
    setInner('<div class="fr-v2348-content"><section class="fr-v2348-panel"><div class="ortho-v25730-box"><div class="ortho-v25730-progress">Segment '+(state.segmentIndex+1)+' / '+state.total+'</div><div class="ortho-dictee-compose'+(imageHtml?' has-image':'')+'">'+imageHtml+'<div><div id="orthoDictModelV25730" class="ortho-dictee-model"><p><strong>Observe et mémorise ce segment :</strong></p><div class="ortho-v25730-question">'+esc(seg)+'</div><button type="button" class="ortho-v25730-btn" onclick="hideHibouSegmentModelV25730()">Je cache le modèle</button></div><div id="orthoDictWriteV25730" class="ortho-dictee-write" hidden><label for="orthoSegmentInputV25730" class="ortho-v25730-model">Écris le segment de mémoire.</label><input id="orthoSegmentInputV25730" class="ortho-v25730-input" autocomplete="off" autocapitalize="sentences" spellcheck="false" placeholder="Écris ici"><div id="orthoFeedbackV25730"></div><div class="ortho-v25730-actions"><button class="ortho-v25730-btn" onclick="checkHibouSegmentV25730()">✅ Vérifier</button></div></div></div></div></div></section></div>');
    var overlay=$('frenchTrainingOverlayV2348'); if(overlay) overlay.classList.add('ortho-qcm-compact');
  }

  window.hideHibouSegmentModelV25730=function(){
    var model=$('orthoDictModelV25730'),writing=$('orthoDictWriteV25730');
    if(!model||!writing) return;
    model.hidden=true; writing.hidden=false;
    var inp=$('orthoSegmentInputV25730'); if(inp) inp.focus();
  };

  window.checkHibouSegmentV25730=function(){
    var inp=$('orthoSegmentInputV25730');if(!inp||inp.disabled||!$('orthoDictModelV25730')||!$('orthoDictModelV25730').hidden)return;
    if(!clean(inp.value)){inp.focus();inp.setAttribute('aria-invalid','true');return;}
    inp.removeAttribute('aria-invalid');
    var expected=state.questions[state.segmentIndex]||'';
    var ok=norm(inp.value)===norm(expected);
    state.attempts++;
    var fb=$('orthoFeedbackV25730');
    if(!ok&&state.attempts===1){
      if(fb)fb.innerHTML='<div class="ortho-v25730-feedback warn">Relis ton texte : vérifie les majuscules, les mots et leurs accords. Tu peux corriger puis vérifier une deuxième fois.</div>';
      inp.focus();return;
    }
    if(ok&&state.attempts===1)state.score++;
    state.answers.push({segment:expected,ok:ok,attempts:state.attempts});inp.disabled=true;
    var next=(state.segmentIndex+1>=state.total)?'Voir le résultat':'Segment suivant';
    if(fb)fb.innerHTML='<div class="ortho-v25730-feedback '+(ok?'ok':'warn')+'">'+(ok?'✅ Segment juste !':'💡 Segment attendu : <strong>'+esc(expected)+'</strong>')+'</div><div class="ortho-v25730-actions"><button class="ortho-v25730-btn" onclick="nextHibouSegmentV25730()">'+next+'</button></div>';
  };
  window.nextHibouSegmentV25730=function(){ state.segmentIndex++; if(state.segmentIndex>=state.total) renderResult(); else renderSegment(); };

  function renderResult(){
    setOrthoTopbar(state.activity,true);
    var total=state.total||state.questions.length||1; var pct=Math.round((state.score/total)*100); var label=activityLabel(state.activity);
    setInner(header('🔤 Orthographe','Entraînement terminé.','Le résultat est ajouté à Mon parcours récent.')+'<div class="fr-v2348-content"><section class="fr-v2348-panel"><div class="fr-v2348-result"><h3>Bravo, entraînement terminé !</h3><div class="fr-v2348-score-grid"><div class="fr-v2348-score-card">Score<b>'+state.score+' / '+total+'</b></div><div class="fr-v2348-score-card">Réussite<b>'+pct+'%</b></div></div><div class="fr-v2348-feedback">'+esc(label)+'</div><div class="fr-v2348-actions"><button type="button" class="fr-v2348-action" onclick="startHibouOrthographeV25730(\''+esc(state.activity)+'\')">🔁 Refaire</button><button type="button" class="fr-v2348-action secondary" onclick="openHibouOrthographeV25730()">← Retour Orthographe</button><button type="button" class="fr-v2348-action secondary" onclick="renderFrenchDomainMenuV25720()">Menu Français</button></div></div></section></div>');
    track(label,total,pct);
  }

  function track(label,total,pct){
    try{
      var detail=label+' — '+state.score+'/'+total+' ('+pct+' %)';
      if(typeof window.hibouTrackEvent==='function'){
        window.hibouTrackEvent({type:'entrainement_orthographe_termine',matiere:'Français',domaine:'Orthographe',titre:'Orthographe — '+label,detail:detail,score:state.score,total:total,source:'orthographe_guide_json'});
      }else if(typeof window.hibouRecordTrainingSuccess==='function'){
        window.hibouRecordTrainingSuccess('français','Orthographe',detail);
      }
    }catch(e){ console.warn('Mon parcours récent non mis à jour pour Orthographe',e); }
  }

  function boot(){ injectStyle(); installMenuPatch(); loadData(false); }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else setTimeout(boot,0);
  window.addEventListener('load',function(){ setTimeout(installMenuPatch,200); });
})();
